# SynodOSS Frontend Design Philosophy

## Chosen Design Approach: Futuristic Glassmorphism Command Center

### Design Movement
**Neo-Glassmorphism** — A premium evolution of glassmorphism that combines translucent UI panels with deep dark backgrounds, vibrant accent colors, and ambient lighting effects. Inspired by advanced command centers, aerospace dashboards, and high-end software interfaces.

### Core Principles
1. **Translucency & Depth**: All interactive elements use frosted glass (backdrop-blur) with subtle transparency, creating layers of visual hierarchy
2. **Ambient Illumination**: Fixed radial gradients in the background (indigo, emerald, rose orbs) provide a living, breathing backdrop
3. **Precision & Clarity**: High-contrast typography on translucent surfaces ensures readability while maintaining the ethereal aesthetic
4. **Purposeful Motion**: Micro-interactions (hover states, loading animations, transitions) feel responsive and intentional, never gratuitous

### Color Philosophy
- **Background**: Deep dark (`#0a0a0a` to `#050510`) — creates contrast for glass panels
- **Accent Palette**: 
  - Indigo/Blue (`#6366f1` to `#818cf8`) — Primary actions, Architect agent
  - Emerald/Green (`#10b981` to `#34d399`) — Success states, Advocate agent
  - Rose/Pink (`#f43f5e` to `#fb7185`) — Critical/Defender agent
  - Amber/Yellow (`#f59e0b` to `#fbbf24`) — Warnings, Verification
- **Glass Surfaces**: `bg-white/5` to `bg-white/10` with `backdrop-blur-xl` or `backdrop-blur-2xl`
- **Borders**: `border-white/10` to `border-white/20` for subtle glass edges

### Layout Paradigm
**Asymmetric Command Center Layout**:
- Dashboard: Hero scan input on the left, recent scans grid on the right
- Scan Detail: Stacked metrics row, full-width conflict table, action-oriented design
- Debate Workspace: Three-column layout (metrics left, transcript center, proposal right) or full-width stacked for mobile

### Signature Elements
1. **Glowing Severity Badges**: Color-coded with soft glow effect (`shadow-lg` with color-tinted shadows)
2. **Pulsing Loader**: Animated dots or gradient spinner for "Agents Deliberating" state
3. **Glass Cards with Gradient Borders**: Subtle top-left bright borders (`border-t-white/20 border-l-white/20`) for depth

### Interaction Philosophy
- **Hover States**: Slight opacity increase (`from-white/10 to-white/5`), blur intensification, and subtle scale (1.02)
- **Active States**: Glowing border, increased opacity, smooth color shift
- **Loading**: Elegant pulsing or gradient-sweep animations
- **Transitions**: All state changes use `transition-all duration-300` for smooth, snappy feel

### Animation Guidelines
- Button presses: `scale(0.97)` on active, 160ms ease-out
- Hover effects: Opacity shift + subtle scale, 200ms ease-out
- Loaders: Gradient sweep or pulsing opacity, continuous
- Card entrances: Stagger by 30-50ms per item
- Respect `prefers-reduced-motion` for accessibility

### Typography System
- **Display Font**: "Outfit" (bold, geometric) for headers and hero text
- **Body Font**: "Inter" (clean, readable) for body text and UI labels
- **Hierarchy**:
  - H1: Outfit 48px bold, gradient text (Indigo → Emerald)
  - H2: Outfit 32px semibold
  - H3: Outfit 24px semibold
  - Body: Inter 16px regular
  - Small: Inter 14px regular, text-white/60
  - Code: "Fira Code" monospace for diffs and technical content

### Brand Essence
**One-line positioning**: SynodOSS is the AI-powered architectural governance platform for fork reconciliation, designed for teams who demand precision and transparency in code conflict resolution.

**Personality adjectives**: Intelligent, Trustworthy, Futuristic

### Brand Voice
- **Headlines**: Technical yet approachable, emphasizing control and clarity
- **CTAs**: Action-oriented, confident ("Start Scan", "Begin Debate", "Accept Resolution")
- **Microcopy**: Informative, never patronizing
- **Example lines**:
  - "Your multi-agent council is ready to reconcile conflicts"
  - "Watch as AI agents debate the optimal resolution"

### Wordmark & Logo
**Logo Concept**: A geometric symbol of three interconnected nodes (representing the fork, upstream, and reconciliation) with a glowing center point, suggesting consensus and connection. The mark uses indigo and emerald gradients. No text, pure symbol.

### Signature Brand Color
**Indigo (#6366f1)**: The primary brand color representing intelligence, precision, and forward-thinking technology. Used in primary buttons, key metrics, and the Architect agent's color.

---

## Implementation Notes
- Use Tailwind 4 with OKLCH color format for semantic tokens
- All glass components inherit from `GlassCard`, `GlassButton`, `GlassBadge` base components
- Ambient background gradients are fixed in `globals.css` using radial gradients
- API integration layer in `lib/api.ts` with centralized error handling
- Polling mechanism for scan and debate status updates
- Skeleton screens for loading states on all data-dependent views
