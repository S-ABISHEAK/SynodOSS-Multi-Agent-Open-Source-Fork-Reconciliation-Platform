import axios, { AxiosError, AxiosInstance } from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

const api: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000,
});

// Error handling
export const handleApiError = (error: unknown): string => {
  if (axios.isAxiosError(error)) {
    const axiosError = error as AxiosError;
    if (axiosError.response?.status === 429) {
      return 'Rate limited. Please try again in a moment.';
    }
    if (axiosError.response?.status === 404) {
      return 'Resource not found.';
    }
    if (axiosError.response?.status === 500) {
      return 'Server error. Please try again later.';
    }
    if (axiosError.code === 'ECONNABORTED') {
      return 'Request timeout. Please check your connection.';
    }
    return axiosError.message || 'An error occurred';
  }
  return 'An unexpected error occurred';
};

// Repository Scan Endpoints
export const scanApi = {
  startScan: async (upstreamUrl: string, forkUrl: string) => {
    try {
      const response = await api.post('/repos/scans/start', {
        upstream_url: upstreamUrl,
        fork_url: forkUrl,
      });
      return response.data;
    } catch (error) {
      console.error('Scan API error:', error);
      throw error;
    }
  },

  getScanStatus: async (scanId: number) => {
    try {
      const response = await api.get(`/scans/${scanId}`);
      return response.data;
    } catch (error) {
      console.error('Get scan status error:', error);
      throw error;
    }
  },

  getScanMetrics: async (scanId: number) => {
    try {
      const response = await api.get(`/scans/${scanId}/metrics`);
      return response.data;
    } catch (error) {
      console.error('Get scan metrics error:', error);
      throw error;
    }
  },

  getReconciliationUnits: async (scanId: number) => {
    try {
      const response = await api.get(`/scans/${scanId}/reconciliation_units`);
      return response.data;
    } catch (error) {
      console.error('Get reconciliation units error:', error);
      throw error;
    }
  },
};

// Debate Endpoints
export const debateApi = {
  startDebate: async (unitId: number) => {
    try {
      const response = await api.post(`/debates/start?unit_id=${unitId}`);
      return response.data;
    } catch (error) {
      console.error('Start debate error:', error);
      throw error;
    }
  },

  getDebateStatus: async (debateId: number) => {
    try {
      const response = await api.get(`/debates/${debateId}`);
      return response.data;
    } catch (error) {
      console.error('Get debate status error:', error);
      throw error;
    }
  },

  getDebateRounds: async (debateId: number) => {
    try {
      const response = await api.get(`/debates/${debateId}/rounds`);
      return response.data;
    } catch (error) {
      console.error('Get debate rounds error:', error);
      throw error;
    }
  },
};

export default api;
