import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Github, Check, AlertCircle, Loader } from 'lucide-react';

export const ScanInputCard: React.FC = () => {
  const [upstreamUrl, setUpstreamUrl] = useState('https://github.com/org/upstream-repo.git');
  const [forkUrl, setForkUrl] = useState('https://github.com/org/fork-repo.git');
  const [isValidating, setIsValidating] = useState(false);
  const [isValid, setIsValid] = useState(false);

  const handleValidate = () => {
    setIsValidating(true);
    setTimeout(() => {
      setIsValidating(false);
      setIsValid(true);
    }, 1500);
  };

  return (
    <motion.div
      className="glass rounded-2xl p-8 col-span-1 lg:col-span-2"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-2">Repository Scan</h2>
        <p className="text-sm text-gray-400">Analyze conflicts between upstream and fork repositories</p>
      </div>

      <div className="space-y-6">
        {/* Upstream Repository */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-3">
            Upstream Repository URL
          </label>
          <motion.div
            className="relative group"
            whileHover={{ scale: 1.01 }}
          >
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 group-focus-within:text-indigo-400 transition-colors">
              <Github size={18} />
            </div>
            <input
              type="text"
              value={upstreamUrl}
              onChange={(e) => setUpstreamUrl(e.target.value)}
              className="w-full pl-12 pr-4 py-3 glass rounded-lg text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
              placeholder="https://github.com/org/upstream-repo.git"
            />
            <motion.div
              className="absolute right-4 top-1/2 transform -translate-y-1/2"
              animate={{ opacity: isValid ? 1 : 0 }}
            >
              <Check size={18} className="text-emerald-400" />
            </motion.div>
          </motion.div>
        </div>

        {/* Fork Repository */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-3">
            Fork Repository URL
          </label>
          <motion.div
            className="relative group"
            whileHover={{ scale: 1.01 }}
          >
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 group-focus-within:text-indigo-400 transition-colors">
              <Github size={18} />
            </div>
            <input
              type="text"
              value={forkUrl}
              onChange={(e) => setForkUrl(e.target.value)}
              className="w-full pl-12 pr-4 py-3 glass rounded-lg text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
              placeholder="https://github.com/org/fork-repo.git"
            />
          </motion.div>
        </div>

        {/* Repository Info (if valid) */}
        {isValid && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4 border-t border-white/10"
          >
            <div className="text-center">
              <p className="text-xs text-gray-400 mb-1">Branch</p>
              <p className="text-sm font-semibold text-white">main</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-400 mb-1">Language</p>
              <p className="text-sm font-semibold text-white">TypeScript</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-400 mb-1">Stars</p>
              <p className="text-sm font-semibold text-white">2.4K</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-400 mb-1">Visibility</p>
              <p className="text-sm font-semibold text-white">Public</p>
            </div>
          </motion.div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4">
          <motion.button
            onClick={handleValidate}
            disabled={isValidating}
            className="flex-1 relative group overflow-hidden rounded-lg py-3 font-semibold transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {/* Gradient background */}
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-blue-600 group-hover:from-indigo-500 group-hover:to-blue-500 transition-all" />
            
            {/* Glow effect */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity blur-xl bg-gradient-to-r from-indigo-600 to-blue-600" />
            
            {/* Content */}
            <div className="relative flex items-center justify-center gap-2 text-white">
              {isValidating ? (
                <>
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity }}>
                    <Loader size={18} />
                  </motion.div>
                  Validating...
                </>
              ) : (
                <>
                  <Zap size={18} />
                  Start Scan
                </>
              )}
            </div>
          </motion.button>

          <motion.button
            className="px-6 py-3 glass rounded-lg text-gray-300 hover:text-white font-semibold transition-colors"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Documentation
          </motion.button>
        </div>

        <p className="text-xs text-gray-500 text-center">
          Scans typically complete in 2-5 minutes
        </p>
      </div>
    </motion.div>
  );
};

import { Zap } from 'lucide-react';
