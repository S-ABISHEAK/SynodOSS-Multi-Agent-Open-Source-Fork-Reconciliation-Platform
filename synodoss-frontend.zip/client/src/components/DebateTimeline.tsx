import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Zap, Shield, Gavel, MessageCircle } from 'lucide-react';

interface TimelineEvent {
  id: string;
  agent: 'architect' | 'advocate' | 'defender' | 'judge';
  timestamp: string;
  message: string;
  isStreaming?: boolean;
}

const mockTimeline: TimelineEvent[] = [
  {
    id: '1',
    agent: 'architect',
    timestamp: '14:32:01',
    message: 'Analyzing AST differences between upstream and fork repositories...',
  },
  {
    id: '2',
    agent: 'advocate',
    timestamp: '14:32:15',
    message: 'Identified 3 critical conflicts in authentication module. Proposing fork-based approach.',
  },
  {
    id: '3',
    agent: 'defender',
    timestamp: '14:32:28',
    message: 'Fork approach breaks backward compatibility. Upstream maintains API contracts.',
    isStreaming: true,
  },
];

const agentConfig = {
  architect: {
    icon: <Brain size={16} />,
    color: 'from-indigo-500 to-indigo-600',
    label: 'Architect',
  },
  advocate: {
    icon: <Zap size={16} />,
    color: 'from-cyan-500 to-cyan-600',
    label: 'Advocate',
  },
  defender: {
    icon: <Shield size={16} />,
    color: 'from-emerald-500 to-emerald-600',
    label: 'Defender',
  },
  judge: {
    icon: <Gavel size={16} />,
    color: 'from-purple-500 to-purple-600',
    label: 'Judge',
  },
};

export const DebateTimeline: React.FC = () => {
  return (
    <motion.div
      className="glass rounded-2xl p-6 col-span-1"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <h3 className="text-lg font-bold text-white mb-4">Debate Timeline</h3>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {mockTimeline.map((event, index) => {
          const agent = agentConfig[event.agent];
          return (
            <motion.div
              key={event.id}
              className="flex gap-3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              {/* Timeline line */}
              <div className="flex flex-col items-center">
                <motion.div
                  className={`p-2 rounded-lg bg-gradient-to-br ${agent.color} text-white`}
                  whileHover={{ scale: 1.1 }}
                >
                  {agent.icon}
                </motion.div>
                {index < mockTimeline.length - 1 && (
                  <div className="w-0.5 h-12 bg-gradient-to-b from-white/20 to-transparent mt-2" />
                )}
              </div>

              {/* Message */}
              <div className="flex-1 pt-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-semibold text-white">{agent.label}</p>
                  <p className="text-xs text-gray-500">{event.timestamp}</p>
                </div>
                <motion.div
                  className="bg-white/5 rounded-lg p-3 border border-white/10 group"
                  whileHover={{ borderColor: 'rgba(255,255,255,0.2)' }}
                >
                  <p className="text-sm text-gray-300 leading-relaxed">{event.message}</p>
                  {event.isStreaming && (
                    <motion.div
                      className="mt-2 flex items-center gap-1"
                      animate={{ opacity: [0.5, 1, 0.5] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-500" />
                      <span className="text-xs text-cyan-400">Streaming response...</span>
                    </motion.div>
                  )}
                </motion.div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Input area */}
      <motion.div
        className="mt-4 pt-4 border-t border-white/10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Add a note..."
            className="flex-1 px-3 py-2 glass rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all"
          />
          <motion.button
            className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <MessageCircle size={16} />
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
};
