import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, GitBranch, Zap, CheckCircle, AlertCircle, Clock } from 'lucide-react';

interface WidgetProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  trend?: number;
  unit?: string;
}

const MetricWidget: React.FC<WidgetProps> = ({ icon, label, value, trend, unit }) => {
  return (
    <motion.div
      className="glass rounded-xl p-4 group cursor-pointer"
      whileHover={{ y: -4, scale: 1.02 }}
      transition={{ type: 'spring', stiffness: 300 }}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="p-2 rounded-lg bg-gradient-to-br from-indigo-500/20 to-cyan-500/20 group-hover:from-indigo-500/30 group-hover:to-cyan-500/30 transition-colors">
          {icon}
        </div>
        {trend !== undefined && (
          <div className={`text-xs font-semibold ${trend > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {trend > 0 ? '+' : ''}{trend}%
          </div>
        )}
      </div>
      <p className="text-xs text-gray-400 mb-1">{label}</p>
      <p className="text-2xl font-bold text-white">
        {value}
        {unit && <span className="text-sm text-gray-400 ml-1">{unit}</span>}
      </p>
    </motion.div>
  );
};

export const DashboardWidgets: React.FC = () => {
  const widgets = [
    {
      icon: <GitBranch size={18} className="text-indigo-400" />,
      label: 'Repositories',
      value: 24,
      trend: 12,
    },
    {
      icon: <AlertCircle size={18} className="text-red-400" />,
      label: 'Conflicts',
      value: 7,
      trend: -23,
    },
    {
      icon: <CheckCircle size={18} className="text-emerald-400" />,
      label: 'Resolved Today',
      value: 12,
      trend: 8,
    },
    {
      icon: <Clock size={18} className="text-cyan-400" />,
      label: 'Avg Debate Time',
      value: 2.4,
      unit: 'min',
      trend: -15,
    },
    {
      icon: <TrendingUp size={18} className="text-emerald-400" />,
      label: 'Success Rate',
      value: 94,
      unit: '%',
      trend: 5,
    },
    {
      icon: <Zap size={18} className="text-yellow-400" />,
      label: 'AI Consensus',
      value: 98,
      unit: '%',
      trend: 2,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {widgets.map((widget, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
        >
          <MetricWidget {...widget} />
        </motion.div>
      ))}
    </div>
  );
};
