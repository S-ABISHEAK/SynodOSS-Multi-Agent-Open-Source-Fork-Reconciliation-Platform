import React from 'react';
import { motion } from 'framer-motion';
import { FileText, AlertCircle, Zap } from 'lucide-react';

interface Conflict {
  id: string;
  file: string;
  language: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  complexity: number;
  recommendation: string;
}

const mockConflicts: Conflict[] = [
  {
    id: '1',
    file: 'src/api/auth.ts',
    language: 'TypeScript',
    severity: 'critical',
    complexity: 92,
    recommendation: 'Merge strategy: Upstream with custom middleware',
  },
  {
    id: '2',
    file: 'src/components/Button.tsx',
    language: 'TypeScript',
    severity: 'high',
    complexity: 68,
    recommendation: 'Adopt fork version with upstream props',
  },
  {
    id: '3',
    file: 'package.json',
    language: 'JSON',
    severity: 'medium',
    complexity: 45,
    recommendation: 'Resolve dependency versions',
  },
];

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'critical':
      return 'from-red-500/20 to-red-600/10 border-red-500/30';
    case 'high':
      return 'from-orange-500/20 to-orange-600/10 border-orange-500/30';
    case 'medium':
      return 'from-yellow-500/20 to-yellow-600/10 border-yellow-500/30';
    case 'low':
      return 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/30';
    default:
      return 'from-gray-500/20 to-gray-600/10 border-gray-500/30';
  }
};

const getSeverityBadgeColor = (severity: string) => {
  switch (severity) {
    case 'critical':
      return 'bg-red-500/20 text-red-400 border-red-500/30';
    case 'high':
      return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
    case 'medium':
      return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    case 'low':
      return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    default:
      return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
  }
};

export const ConflictVisualization: React.FC = () => {
  return (
    <motion.div
      className="glass rounded-2xl p-6 col-span-1 lg:col-span-2"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.15 }}
    >
      <h3 className="text-lg font-bold text-white mb-4">Conflict Overview</h3>

      <div className="space-y-3">
        {mockConflicts.map((conflict, index) => (
          <motion.div
            key={conflict.id}
            className={`border glass rounded-xl p-4 group cursor-pointer transition-all ${getSeverityColor(
              conflict.severity
            )}`}
            whileHover={{ scale: 1.02, y: -2 }}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <div className="flex items-start gap-4">
              {/* File Icon */}
              <div className="p-2 rounded-lg bg-white/5 group-hover:bg-white/10 transition-colors">
                <FileText size={18} className="text-indigo-400" />
              </div>

              {/* File Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <p className="text-sm font-semibold text-white truncate">{conflict.file}</p>
                  <span className="text-xs px-2 py-1 rounded bg-white/10 text-gray-400">
                    {conflict.language}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mb-3">{conflict.recommendation}</p>

                {/* Complexity Bar */}
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-indigo-500 to-cyan-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${conflict.complexity}%` }}
                      transition={{ duration: 0.8, delay: index * 0.1 + 0.2 }}
                    />
                  </div>
                  <span className="text-xs text-gray-400 w-8 text-right">{conflict.complexity}%</span>
                </div>
              </div>

              {/* Severity Badge */}
              <div className="flex flex-col items-end gap-2">
                <motion.div
                  className={`px-3 py-1 rounded-lg text-xs font-semibold border ${getSeverityBadgeColor(
                    conflict.severity
                  )}`}
                  whileHover={{ scale: 1.05 }}
                >
                  {conflict.severity.charAt(0).toUpperCase() + conflict.severity.slice(1)}
                </motion.div>

                {/* Start Debate Button */}
                <motion.button
                  className="px-3 py-1 rounded-lg text-xs font-semibold bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 border border-indigo-500/30 transition-colors flex items-center gap-1"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Zap size={12} />
                  Debate
                </motion.button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Summary */}
      <motion.div
        className="mt-4 pt-4 border-t border-white/10 grid grid-cols-3 gap-3"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <div className="text-center">
          <p className="text-xs text-gray-400 mb-1">Total Conflicts</p>
          <p className="text-lg font-bold text-white">{mockConflicts.length}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-400 mb-1">Avg Complexity</p>
          <p className="text-lg font-bold text-white">
            {Math.round(mockConflicts.reduce((a, c) => a + c.complexity, 0) / mockConflicts.length)}%
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs text-gray-400 mb-1">Critical</p>
          <p className="text-lg font-bold text-red-400">
            {mockConflicts.filter((c) => c.severity === 'critical').length}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};
