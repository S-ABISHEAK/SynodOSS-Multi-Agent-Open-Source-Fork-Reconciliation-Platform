import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Shield, Zap, Gavel } from 'lucide-react';

interface Agent {
  name: string;
  icon: React.ReactNode;
  color: string;
  status: 'idle' | 'thinking' | 'debating' | 'finished';
  description: string;
}

const agents: Agent[] = [
  {
    name: 'Architect',
    icon: <Brain size={20} />,
    color: 'from-indigo-500 to-indigo-600',
    status: 'thinking',
    description: 'Analyzes system design',
  },
  {
    name: 'Advocate',
    icon: <Zap size={20} />,
    color: 'from-cyan-500 to-cyan-600',
    status: 'debating',
    description: 'Proposes solutions',
  },
  {
    name: 'Defender',
    icon: <Shield size={20} />,
    color: 'from-emerald-500 to-emerald-600',
    status: 'idle',
    description: 'Challenges proposals',
  },
  {
    name: 'Judge',
    icon: <Gavel size={20} />,
    color: 'from-purple-500 to-purple-600',
    status: 'finished',
    description: 'Reaches consensus',
  },
];

const statusConfig = {
  idle: { dot: 'bg-gray-500', pulse: false, label: 'Idle' },
  thinking: { dot: 'bg-yellow-500', pulse: true, label: 'Thinking' },
  debating: { dot: 'bg-cyan-500', pulse: true, label: 'Debating' },
  finished: { dot: 'bg-emerald-500', pulse: false, label: 'Finished' },
};

export const AgentStatusCard: React.FC = () => {
  return (
    <motion.div
      className="glass rounded-2xl p-6 col-span-1"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
    >
      <h3 className="text-lg font-bold text-white mb-4">AI Council Status</h3>
      
      <div className="space-y-3">
        {agents.map((agent, index) => {
          const status = statusConfig[agent.status];
          return (
            <motion.div
              key={agent.name}
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors cursor-pointer group"
              whileHover={{ x: 4 }}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              {/* Agent Icon */}
              <div className={`p-2 rounded-lg bg-gradient-to-br ${agent.color} text-white group-hover:scale-110 transition-transform`}>
                {agent.icon}
              </div>

              {/* Agent Info */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white">{agent.name}</p>
                <p className="text-xs text-gray-400">{agent.description}</p>
              </div>

              {/* Status Indicator */}
              <div className="flex items-center gap-2">
                <motion.div
                  className={`w-2 h-2 rounded-full ${status.dot}`}
                  animate={status.pulse ? { scale: [1, 1.5, 1] } : {}}
                  transition={status.pulse ? { duration: 2, repeat: Infinity } : {}}
                />
                <span className="text-xs text-gray-400 whitespace-nowrap">{status.label}</span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Council Activity */}
      <motion.div
        className="mt-4 pt-4 border-t border-white/10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <p className="text-xs text-gray-400 mb-2">Current Activity</p>
        <div className="flex items-center gap-2">
          <motion.div
            className="w-1.5 h-1.5 rounded-full bg-cyan-500"
            animate={{ scale: [1, 1.5, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
          <p className="text-sm text-gray-300">Debate in progress...</p>
        </div>
      </motion.div>
    </motion.div>
  );
};
