import React, { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { motion } from 'framer-motion';
import { ConflictVisualization } from '@/components/ConflictVisualization';
import { DebateTimeline } from '@/components/DebateTimeline';
import { DashboardWidgets } from '@/components/DashboardWidgets';
import { scanApi, debateApi, handleApiError } from '@/lib/api';
import { toast } from 'sonner';
import { ArrowLeft, CheckCircle, AlertCircle } from 'lucide-react';

interface ReconciliationUnit {
  id: number;
  file_path: string;
  conflict_type: string;
  severity: string;
  complexity_score: number;
  impact_score: number;
}

interface ScanMetrics {
  commit_gap?: number;
  added_files?: number;
  deleted_files?: number;
  modified_files?: number;
}

export default function ScanDetail() {
  const [, navigate] = useLocation();
  const { id: scanId } = useParams<{ id: string }>();
  const [loading, setLoading] = useState(true);
  const [units, setUnits] = useState<ReconciliationUnit[]>([]);
  const [metrics, setMetrics] = useState<ScanMetrics | null>(null);
  const [scanStatus, setScanStatus] = useState<string>('pending');
  const [startingDebate, setStartingDebate] = useState<number | null>(null);

  useEffect(() => {
    const loadData = async () => {
      if (!scanId) return;

      try {
        const scanIdNum = parseInt(scanId);
        
        // Load scan status
        const status = await scanApi.getScanStatus(scanIdNum);
        setScanStatus(status.status);

        // Load metrics
        const metricsData = await scanApi.getScanMetrics(scanIdNum);
        setMetrics(metricsData);

        // Load reconciliation units
        const unitsData = await scanApi.getReconciliationUnits(scanIdNum);
        setUnits(unitsData);
      } catch (error) {
        const message = handleApiError(error);
        toast.error(message);
      } finally {
        setLoading(false);
      }
    };

    loadData();

    // Poll for updates if scan is still running
    const interval = setInterval(() => {
      if (scanStatus === 'pending' || scanStatus === 'running') {
        loadData();
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [scanId, scanStatus]);

  const handleStartDebate = async (unitId: number) => {
    setStartingDebate(unitId);
    try {
      const result = await debateApi.startDebate(unitId);
      const debateId = result.debate_id;
      toast.success(`Debate started! ID: ${debateId}`);
      navigate(`/debates/${debateId}`);
    } catch (error) {
      const message = handleApiError(error);
      toast.error(message);
    } finally {
      setStartingDebate(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity }}>
          <AlertCircle size={32} className="text-gray-600" />
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.section
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* Back Button */}
        <motion.button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-6"
          whileHover={{ x: -4 }}
        >
          <ArrowLeft size={18} />
          Back to Dashboard
        </motion.button>

        {/* Title Section */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <motion.h1
              className="text-3xl md:text-4xl font-bold text-white mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              Scan Analysis
            </motion.h1>
            <motion.p
              className="text-gray-400"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              Scan ID: <span className="font-mono text-indigo-400">{scanId}</span>
            </motion.p>
          </div>

          {/* Status Badge */}
          <motion.div
            className={`flex items-center gap-2 px-4 py-2 glass rounded-lg ${
              scanStatus === 'completed'
                ? 'bg-emerald-500/10 border-emerald-500/30'
                : scanStatus === 'failed'
                ? 'bg-red-500/10 border-red-500/30'
                : 'bg-amber-500/10 border-amber-500/30'
            } border`}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <motion.div
              className={`w-2 h-2 rounded-full ${
                scanStatus === 'completed'
                  ? 'bg-emerald-500'
                  : scanStatus === 'failed'
                  ? 'bg-red-500'
                  : 'bg-amber-500'
              }`}
              animate={{ scale: [1, 1.5, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <span
              className={`text-sm font-semibold ${
                scanStatus === 'completed'
                  ? 'text-emerald-400'
                  : scanStatus === 'failed'
                  ? 'text-red-400'
                  : 'text-amber-400'
              }`}
            >
              {scanStatus.charAt(0).toUpperCase() + scanStatus.slice(1)}
            </span>
          </motion.div>
        </div>
      </motion.section>

      {/* Main Content Grid */}
      <section className="container mx-auto px-4 pb-16">
        {/* Metrics Overview */}
        {metrics && (
          <motion.div
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h2 className="text-xl font-bold text-white mb-4">Metrics Overview</h2>
            <DashboardWidgets />
          </motion.div>
        )}

        {/* Conflicts and Timeline */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <ConflictVisualization />
          <DebateTimeline />
        </div>

        {/* Architectural Proposal */}
        <motion.div
          className="glass rounded-2xl p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h2 className="text-xl font-bold text-white mb-4">Architectural Proposal</h2>

          <div className="space-y-4">
            <div className="border border-white/10 rounded-xl p-4 bg-white/5">
              <div className="flex items-start gap-3 mb-3">
                <CheckCircle size={20} className="text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white mb-1">Recommended Strategy</p>
                  <p className="text-sm text-gray-400">
                    Merge upstream main branch with selective fork features. Maintain API compatibility while adopting
                    fork's improved type safety.
                  </p>
                </div>
              </div>
            </div>

            <div className="border border-white/10 rounded-xl p-4 bg-white/5">
              <div className="flex items-start gap-3 mb-3">
                <AlertCircle size={20} className="text-yellow-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white mb-1">Potential Issues</p>
                  <p className="text-sm text-gray-400">
                    Authentication module requires careful integration. Test fork's middleware with upstream's session
                    management.
                  </p>
                </div>
              </div>
            </div>

            <div className="border border-indigo-500/30 rounded-xl p-4 bg-indigo-500/10">
              <p className="text-sm text-indigo-200 mb-3">Consensus Level: 94%</p>
              <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-indigo-500 to-cyan-500"
                  initial={{ width: 0 }}
                  animate={{ width: '94%' }}
                  transition={{ duration: 1, delay: 0.6 }}
                />
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-6 pt-6 border-t border-white/10">
            <motion.button
              className="flex-1 px-4 py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-semibold rounded-lg transition-all"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Accept Proposal
            </motion.button>
            <motion.button
              className="flex-1 px-4 py-3 glass text-gray-300 hover:text-white font-semibold rounded-lg transition-colors"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              View Diff
            </motion.button>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
